import { cn } from "@/lib/utils"

function Skeleton({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="skeleton"
      className={cn("rounded-md bg-muted/90", "ds-skeleton-shimmer", className)}
      {...props}
    />
  )
}

export { Skeleton }
